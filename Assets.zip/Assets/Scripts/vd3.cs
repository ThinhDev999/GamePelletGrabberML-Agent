// // using UnityEngine;
// // using Unity.MLAgents;
// // using Unity.MLAgents.Actuators;
// // using Unity.MLAgents.Sensors;
// // // using System.Numerics;
// // using System.Collections;
// // using System.Collections.Generic;

// // public class AgentController : Agent

// // {
// //     [SerializeField] private Transform target;
// //     public int pelletCount;
// //     public GameObject food;
// //     public List<GameObject> spawnedPelletsList = new List<GameObject>();

// //     // Agent variables
// //     [SerializeField] private float moveSpeed = 4f;
// //     private Rigidbody rb;

// //     // Environment variables
// //     [SerializeField] private Transform environmentLocation;
// //     private Material envMaterial;
// //     public GameObject env;

// //     public override void Initialize()
// //     {
// //         rb = GetComponent<Rigidbody>();
// //         envMaterial = env.GetComponent<Renderer>().material;
// //     }

// //     public override void OnEpisodeBegin()
// //     {
// //         // Agent reset
// //         transform.localPosition = new Vector3(Random.Range(-4f, 4f), 0.3f, Random.Range(-4f, 4f));

// //         // Spawn pellets
// //         CreatePellet();
// //     }
// //     // public override void OnEpisodeBegin()
// //     // {
// //     //     transform.localPosition = new Vector3(Random.Range(-4f, 4f), 0.3f, Random.Range(-4f, 4f));

// //     //     target.localPosition = new Vector3(Random.Range(-4f, 4f), 0.3f, Random.Range(-4f, 4f));
// //     //     // transform.localPosition = new Vector3(0f, 0.3f, 0f);

// //     //     // int rand = Random.Range(0, 2);

// //     //     // if (rand == 0)
// //     //     // {
// //     //     //     target.localPosition = new Vector3(-4f, 0.3f, 0f);
// //     //     // }
// //     //     // if (rand == 1)
// //     //     // {
// //     //     //     target.localPosition = new Vector3(4f, 0.3f, 0f);
// //     //     // }
// //     // }
// //     private void CreatePellet()
// //     {
// //         if (spawnedPelletsList.Count != 0)
// //         {
// //             RemovePellet(spawnedPelletsList);
// //         }

// //         for (int i = 0; i < pelletCount; i++)
// //         {
// //             // Spawning pellet
// //             GameObject newPellet = Instantiate(food);
// //             // Make pellet child of the environment
// //             newPellet.transform.parent = environmentLocation;
// //             // Give random spawn location
// //             Vector3 pelletLocation = new Vector3(Random.Range(-4f, 4f), 0.3f, Random.Range(-4f, 4f));
// //             // "Spawn" in new location
// //             newPellet.transform.localPosition = pelletLocation;
// //             // Add to list
// //             spawnedPelletsList.Add(newPellet);
// //             Debug.Log("Spawned");
// //         }
// //     }

// //     private void RemovePellet(List<GameObject> toBeDeletedGameObjectList)
// //     {
// //         foreach (GameObject obj in toBeDeletedGameObjectList)
// //         {
// //             Destroy(obj);
// //         }
// //         toBeDeletedGameObjectList.Clear();
// //     }

// //     public override void CollectObservations(VectorSensor sensor)
// //     {
// //         sensor.AddObservation(transform.localPosition);
// //         // sensor.AddObservation(target.localPosition);
// //     }

// //     public override void OnActionReceived(ActionBuffers actions)
// //     {
// //         // float moveX = actions.ContinuousActions[0];
// //         // float moveZ = actions.ContinuousActions[1];
// //         // moveSpeed = 4f;

// //         // Vector3 velocity = new Vector3(moveX, 0f, moveZ) * Time.deltaTime * moveSpeed;

// //         // velocity = velocity.normalized * Time.deltaTime * moveSpeed;
// //         // transform.localPosition += velocity;

// //         float moveRotate = actions.ContinuousActions[0];
// //         float moveForward = actions.ContinuousActions[1];

// //         rb.MovePosition(transform.position + transform.forward * moveForward * moveSpeed * Time.deltaTime);
// //         transform.Rotate(0f, moveRotate * moveSpeed, 0f, Space.Self);

// //         // float move = actions.ContinuousActions[0];
// //         // float moveSpeed = 2f;

// //         // transform.localPosition += new Vector3(move, 0f) * Time.deltaTime * moveSpeed;
// //     }

// //     public override void Heuristic(in ActionBuffers actionsOut)
// //     {
// //         ActionSegment<float> continuousActions = actionsOut.ContinuousActions;
// //         continuousActions[0] = Input.GetAxisRaw("Horizontal");
// //         continuousActions[1] = Input.GetAxisRaw("Vertical");
// //     }

// //     private void OnTriggerEnter(Collider other)
// //     {
// //         if (other.gameObject.tag == "Pellet")
// //         {
// //             // Remove from list
// //             spawnedPelletsList.Remove(other.gameObject);
// //             Debug.Log(spawnedPelletsList.Count);
// //             Destroy(other.gameObject);
// //             AddReward(10f);
// //             if (spawnedPelletsList.Count == 0)
// //             {
// //                 envMaterial.color = Color.green;
// //                 RemovePellet(spawnedPelletsList);
// //                 AddReward(5f);
// //                 EndEpisode();
// //             }
// //         }

// //         if (other.gameObject.tag == "Wall")
// //         {
// //             envMaterial.color = Color.red;
// //             RemovePellet(spawnedPelletsList);
// //             AddReward(-15f);
// //             EndEpisode();
// //         }
// //     }
// // }

// using UnityEngine;
// using Unity.MLAgents;
// using Unity.MLAgents.Actuators;
// using Unity.MLAgents.Sensors;
// // using System.Numerics;
// // using System.Collections.Generic;
// // using System.Collections;

// public class AgentController : Agent

// {
//     [SerializeField] private Transform target;
//     [SerializeField] private float moveSpeed = 4f;

//     private Rigidbody rb;

//     public override void Initialize()

//     {
//         rb = GetComponent<Rigidbody>();
//     }

//     public override void OnEpisodeBegin()
//     {
//         transform.localPosition = new Vector3(Random.Range(-4f, 4f), 0.3f, Random.Range(-4f, 4f));

//         target.localPosition = new Vector3(Random.Range(-4f, 4f), 0.3f, Random.Range(-4f, 4f));
//         // transform.localPosition = new Vector3(0f, 0.3f, 0f);

//         // int rand = Random.Range(0, 2);

//         // if (rand == 0)
//         // {
//         //     target.localPosition = new Vector3(-4f, 0.3f, 0f);
//         // }
//         // if (rand == 1)
//         // {
//         //     target.localPosition = new Vector3(4f, 0.3f, 0f);
//         // }
//     }

//     public override void CollectObservations(VectorSensor sensor)
//     {
//         sensor.AddObservation(transform.localPosition);
//         // sensor.AddObservation(target.localPosition);
//     }

//     public override void OnActionReceived(ActionBuffers actions)
//     {
//         // float moveX = actions.ContinuousActions[0];
//         // float moveZ = actions.ContinuousActions[1];
//         // moveSpeed = 4f;

//         // Vector3 velocity = new Vector3(moveX, 0f, moveZ) * Time.deltaTime * moveSpeed;

//         // velocity = velocity.normalized * Time.deltaTime * moveSpeed;
//         // transform.localPosition += velocity;

//         float moveRotate = actions.ContinuousActions[0];
//         float moveForward = actions.ContinuousActions[1];

//         rb.MovePosition(transform.position + transform.forward * moveForward * moveSpeed * Time.deltaTime);
//         transform.Rotate(0f, moveRotate * moveSpeed, 0f, Space.Self);

//         // float move = actions.ContinuousActions[0];
//         // float moveSpeed = 2f;

//         // transform.localPosition += new Vector3(move, 0f) * Time.deltaTime * moveSpeed;
//     }

//     public override void Heuristic(in ActionBuffers actionsOut)
//     {
//         ActionSegment<float> continuousActions = actionsOut.ContinuousActions;
//         continuousActions[0] = Input.GetAxisRaw("Horizontal");
//         continuousActions[1] = Input.GetAxisRaw("Vertical");
//     }

//     private void OnTriggerEnter(Collider other)
//     {
//         if (other.gameObject.tag == "Pellet")
//         {
//             AddReward(2f);
//             EndEpisode();
//         }
//         if (other.gameObject.tag == "Wall")
//         {
//             AddReward(-1f);
//             EndEpisode();
//         }
//     }

// }